# -*- coding: utf-8 -*-
import os
import json
import csv
import requests
from datetime import datetime
import sys
import time
import glob
from pathlib import Path


# ==============================================================================
# UTF-8 SAFE STDOUT/STDERR (Windows / PyInstaller)
# ==============================================================================
def _force_utf8_stdio() -> None:
    """
    Garante que prints/logs não quebrem em Windows (cp1252) quando houver Unicode.
    - Força UTF-8 (quando possível)
    - E usa 'backslashreplace' para nunca dar UnicodeEncodeError
    """
    try:
        import os as _os
        import sys as _sys
        _os.environ.setdefault("PYTHONIOENCODING", "utf-8")
        _os.environ.setdefault("PYTHONUTF8", "1")
        if hasattr(_sys.stdout, "reconfigure"):
            _sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
        if hasattr(_sys.stderr, "reconfigure"):
            _sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:
        pass

_force_utf8_stdio()

try:
    # IA opcional para enriquecimento automático de descrições de medidas
    from google import genai
except ImportError:
    genai = None

# ==============================================================================
# CONFIGURAÇÕES (V28 - Page Unifier + Visual Label + Big DAX)
# ==============================================================================
def load_notion_config() -> dict:
    """
    Carrega configurações do Notion a partir de notion_config.json localizado
    na mesma pasta do executável (.exe) ou do script .py.
    """
    if getattr(sys, "frozen", False):
        base_dir = Path(sys.executable).resolve().parent
    else:
        base_dir = Path(__file__).resolve().parent

    config_path = base_dir / "notion_config.json"

    if not config_path.is_file():
        print(f"[ERRO] Arquivo 'notion_config.json' não encontrado em: {config_path}")
        print("       Crie e configure esse arquivo antes de rodar o Constructor (V4).")
        sys.exit(1)

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[ERRO] Falha ao ler/parsear 'notion_config.json': {e}")
        sys.exit(1)

    token = data.get("notion_api_key") or ""
    if not token:
        print("[ERRO] Campo 'notion_api_key' ausente ou vazio em notion_config.json.")
        sys.exit(1)

    databases = data.get("databases") or {}
    hub_db_id = databases.get("pbi_inventory_hub") or ""
    if not hub_db_id:
        print("[ERRO] Campo 'databases.pbi_inventory_hub' ausente ou vazio em notion_config.json.")
        print("       Ajuste o arquivo antes de executar o Constructor (V4).")
        sys.exit(1)

    return {
        "token": token,
        "hub_database_id": hub_db_id,
        "raw": data,
        "config_path": str(config_path),
    }


_notion_cfg = load_notion_config()
NOTION_TOKEN = _notion_cfg["token"]
DATABASE_ID = _notion_cfg["hub_database_id"]

HEADERS = {
    "Authorization": f"Bearer {NOTION_TOKEN}",
    "Content-Type": "application/json",
    "Notion-Version": "2022-06-28"
}

# ==============================================================================
# IA HELPERS - GEMINI (Enriquecimento automático de descrições)
# ==============================================================================
def load_ai_config() -> dict | None:
    """
    Carrega configurações de IA a partir de ai_config.json localizado
    na mesma pasta do executável (.exe) ou do script .py.

    Esperado (exemplo):
    {
        "provider": "google-gemini",
        "api_key": "SUA_CHAVE_AQUI",
        "default_model": "gemini-2.5-flash"
    }
    """
    if getattr(sys, "frozen", False):
        base_dir = Path(sys.executable).resolve().parent
    else:
        base_dir = Path(__file__).resolve().parent

    config_path = base_dir / "ai_config.json"

    if not config_path.is_file():
        print(f"[AVISO] Arquivo 'ai_config.json' não encontrado em: {config_path}")
        print("        use_ai_enrichment = true no pbi_config.json, mas a IA será ignorada nesta rodada.")
        return None

    try:
        data = json.loads(config_path.read_text(encoding='utf-8'))
    except Exception as e:
        print(f"[AVISO] Falha ao ler/parsear 'ai_config.json': {e}")
        print("        Enriquecimento por IA será ignorado nesta rodada.")
        return None

    api_key = (data.get("api_key") or "").strip()
    provider = (data.get("provider") or "google-gemini").strip()
    default_model = (data.get("default_model") or "").strip()

    if not api_key:
        print("[AVISO] Campo 'api_key' ausente ou vazio em ai_config.json. IA será ignorada nesta rodada.")
        return None

    return {
        "api_key": api_key,
        "provider": provider,
        "default_model": default_model,
    }


def get_gemini_client():
    """
    Cria o client do Gemini usando as configurações do arquivo ai_config.json.
    Se a lib não estiver instalada ou a chave não existir, retorna None.
    """
    if genai is None:
        print("[AVISO] google-genai não instalado. Enriquecimento por IA será ignorado.")
        return None

    cfg_ai = load_ai_config()
    if cfg_ai is None:
        return None

    try:
        client = genai.Client(api_key=cfg_ai["api_key"])
        return client
    except Exception as e:
        print(f"[AVISO] Falha ao criar cliente Gemini: {e}")
        return None


def ai_enrich_measures(structure, project_name, model_name, existing_descriptions):
    """
    Gera descrições humanizadas para medidas via Gemini.
    Só chama a IA para medidas que ainda não possuem descrição em existing_descriptions.
    Retorna um dicionário {measure_name: description}.
    """
    client = get_gemini_client()
    if client is None:
        return {}

    measures = structure.get("measures", [])
    # filtra só as medidas que ainda não têm descrição
    target_measures = [m for m in measures if not existing_descriptions.get(m.get("name", ""), "").strip()]
    total = len(target_measures)
    if total == 0:
        print("[INFO] Todas as medidas já possuem descrição em cache. Nenhuma chamada à IA será feita.")
        return {}

    print(f"--- 1.A Enriquecendo descrições via IA ({total} medidas novas) ---")
    new_descriptions = {}

    for i, m in enumerate(target_measures, start=1):
        dax_snippet = m.get("dax", "")
        name = m.get("name", "")
        table = m.get("table", "")

        prompt = f"""
Você é um consultor sênior de BI ajudando a documentar um modelo de dados em Power BI.

Sua tarefa é escrever uma descrição curta (1 a 2 frases, em português do Brasil), simples e objetiva, que qualquer pessoa de negócio consiga entender, explicando o que a medida faz.

Não invente contexto de negócio. Use apenas:
- o nome da medida,
- o nome da tabela e
- a definição DAX abaixo.

Se o domínio (por exemplo, RH, Finanças, Marketing, Operações etc.) não ficar claro a partir desses elementos, use uma linguagem neutra, sem citar áreas de negócio. Se ele ficar evidente (porque aparece no nome do projeto, da tabela ou da medida), você pode mencioná-lo de forma natural.

Contexto do projeto (apenas como referência, não invente nada além do que estiver claro): {project_name}
Nome da medida: [{name}]
Tabela de medidas: {table}

Definição DAX:
```DAX
{dax_snippet}
```

Na sua resposta:
- Explique o que a medida retorna (contagem, soma, média, taxa, variação etc.).
- Se possível, comente o escopo básico (período, filtros, se considera apenas registros ativos etc.), mas somente se isso estiver evidente no DAX ou nos nomes.

IMPORTANTE:
- Não inclua o código DAX na resposta.
- Não use bullet points, numeração, markdown ou emojis.
- Retorne APENAS o texto da descrição final, em uma ou duas frases.
""".strip()

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
            )
            text = (response.text or "").strip()
        except Exception as e:
            print(f"[AVISO] Falha ao descrever medida {name} ({i}/{total}): {e}")
            text = ""

        new_descriptions[name] = text

        if i % 50 == 0 or i == total:
            print(f"  - IA: {i}/{total} medidas processadas...")

        # Pequeno intervalo para evitar qualquer throttle agressivo
        time.sleep(0.1)

    return new_descriptions


def save_measures_enriched(structure, descriptions_by_name, path="measures_enriched.csv"):
    """
    Salva/atualiza um cache local com as descrições das medidas
    para reaproveitar em execuções futuras.
    Chave de controle = nome da medida.
    """
    fieldnames = ["global_id", "measure_name", "description"]
    try:
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for m in structure.get("measures", []):
                gid = m.get("global_id") or ""
                name = m.get("name", "")
                desc = descriptions_by_name.get(name, "")
                writer.writerow({
                    "global_id": gid,
                    "measure_name": name,
                    "description": desc
                })
        print(f"--- Cache de descrições salvo em {path} ({len(structure.get('measures', []))} medidas) ---")
    except Exception as e:
        print(f"[AVISO] Não foi possível salvar {path}: {e}")


# ==============================================================================
# 1. CARREGAMENTO E UNIFICAÇÃO
# ==============================================================================
def load_data():
    print("--- 1. Carregando Dados (V28 + IA + Visual Label) ---")
    if not os.path.exists("pbi_config.json"):
        sys.exit("[ERRO] pbi_config.json ausente.")
    if not os.path.exists("model_structure.json"):
        sys.exit("[ERRO] model_structure.json ausente. Rode o minerador_pbi.py primeiro.")

    with open("pbi_config.json", "r", encoding="utf-8") as f:
        config = json.load(f)
    with open("model_structure.json", "r", encoding="utf-8") as f:
        structure = json.load(f)

    # Flag de controle do enriquecimento por IA (padrão: False se não existir no config)
    use_ai = config.get("use_ai_enrichment", False)
    ai_model = config.get("ai_model", "gemini-2.5-flash")

    # Dicionário mestre de descrições, mapeado por NOME da medida
    descriptions_by_name = {}

    # 1) Tenta reaproveitar descrições existentes de um cache local (measures_enriched.csv)
    if os.path.exists("measures_enriched.csv"):
        try:
            with open("measures_enriched.csv", "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if not row:
                        continue
                    name = (row.get("measure_name") or "").strip()
                    desc = (row.get("description") or "").strip()
                    if name:
                        descriptions_by_name[name] = desc
            print(f"--- Cache de descrições carregado de measures_enriched.csv ({len(descriptions_by_name)} medidas) ---")
        except Exception as e:
            print(f"[AVISO] Falha ao ler measures_enriched.csv, seguirá sem cache: {e}")
            descriptions_by_name = {}
    else:
        print("[INFO] Nenhum measures_enriched.csv encontrado. Cache de descrições começará vazio.")

    # 2) Se IA estiver habilitada, gera/atualiza descrições via Gemini
    if use_ai:
        project_name = config.get("project_name", "")
        ai_desc = ai_enrich_measures(structure, project_name, ai_model, descriptions_by_name)

        # IA tem precedência sobre cache antigo
        for name, desc in ai_desc.items():
            if desc is not None:
                descriptions_by_name[name] = desc
    else:
        print("[INFO] Enriquecimento por IA desabilitado (use_ai_enrichment = false ou ausência no pbi_config.json).")

    # 3) UNIFICAÇÃO INTELIGENTE DE PÁGINAS (COM LABEL DO VISUAL)
    unified_pages = {}

    # 3.1. Base principal: report_structure vindo do Minerador
    raw_pages = structure.get("report_structure", [])
    for p in raw_pages:
        p_name = p.get("name", "Geral")
        if p_name not in unified_pages:
            unified_pages[p_name] = []

        current_ids = {v["id"] for v in unified_pages[p_name]}
        for v in p.get("visuals", []):
            if v["id"] not in current_ids:
                # Garante que existe campo label mesmo que vazio
                unified_pages[p_name].append({
                    "id": v.get("id"),
                    "type": v.get("type", "Visual Desconhecido"),
                    "label": v.get("label", ""),
                    "measures": list(set(v.get("measures", [])))
                })
                current_ids.add(v["id"])

    # 3.2. Fallback / complemento: visuais referenciados pelos detalhes das medidas
    for m in structure.get("measures", []):
        vis_details = m.get("visual_details", [])
        for v in vis_details:
            p_name = v.get("page", "Geral")
            if p_name not in unified_pages:
                unified_pages[p_name] = []

            v_id = v.get("id")
            v_type = v.get("type", "Visual Desconhecido")
            v_label = v.get("label", "")  # pode vir do minerador se mapeado lá

            found = False
            for existing_v in unified_pages[p_name]:
                if existing_v["id"] == v_id:
                    if m["name"] not in existing_v["measures"]:
                        existing_v["measures"].append(m["name"])
                    found = True
                    break

            if not found:
                unified_pages[p_name].append({
                    "id": v_id,
                    "type": v_type,
                    "label": v_label,
                    "measures": [m["name"]]
                })

    # Injeta de volta na estrutura para uso nos builders
    structure["unified_pages"] = unified_pages

    # Enriquece medidas (descrições) usando dicionário por NOME
    for m in structure.get("measures", []):
        m_name = m.get("name", "")
        m["desc"] = descriptions_by_name.get(m_name, "")
        m["visual_text"] = "Sim" if m.get("in_visual") else "Não"

    print(f"> Páginas unificadas para processamento: {len(unified_pages)}")

    # Atualiza / garante measures_enriched.csv SEMPRE (com ou sem IA)
    save_measures_enriched(structure, descriptions_by_name, path="measures_enriched.csv")

    return config, structure


# ==============================================================================
# 2. API HELPERS
# ==============================================================================
def create_inline_db(parent_id, title, properties):
    url = "https://api.notion.com/v1/databases"
    payload = {
        "parent": {"page_id": parent_id},
        "title": [{"type": "text", "text": {"content": title}}],
        "properties": properties,
        "is_inline": True
    }
    try:
        resp = requests.post(url, headers=HEADERS, json=payload)
        data = resp.json()
        if resp.status_code != 200 or "id" not in data:
            print(f"[ERRO] Falha ao criar database inline '{title}'")
            print("Status:", resp.status_code)
            print("Resposta:", data)
            return None
        return data["id"]
    except Exception as e:
        print(f"[ERRO] Exceção ao criar database inline '{title}': {e}")
        return None


def add_row_heavy(db_id, props, children_blocks, name="Row"):
    url_create = "https://api.notion.com/v1/pages"
    payload_create = {"parent": {"database_id": db_id}, "properties": props}

    page_id = None
    for _ in range(3):
        try:
            r = requests.post(url_create, headers=HEADERS, json=payload_create)
            if r.status_code == 200:
                page_id = r.json()["id"]
                break
            elif r.status_code == 429:
                print(f"[INFO] Notion 429 (rate limit) ao criar linha '{name}'. Aguardando...")
                time.sleep(5)
            else:
                print(f"[ERRO] Notion {r.status_code} ao criar linha '{name}': {r.text}")
                time.sleep(1)
        except Exception as e:
            print(f"[EXC] Exceção ao criar linha '{name}': {e}")
            time.sleep(1)

    if not page_id:
        print(f"[ERRO] Falha ao criar linha: {name}")
        return None

    url_app = f"https://api.notion.com/v1/blocks/{page_id}/children"
    batch = 80
    if children_blocks:
        for i in range(0, len(children_blocks), batch):
            req_batch = children_blocks[i:i + batch]
            for _ in range(3):
                try:
                    r = requests.patch(url_app, headers=HEADERS, json={"children": req_batch})
                    if r.status_code == 200:
                        break
                    elif r.status_code == 429:
                        print(f"[INFO] Notion 429 (rate limit) ao anexar blocks da linha '{name}'. Aguardando...")
                        time.sleep(5)
                    else:
                        print(f"[ERRO] Notion {r.status_code} ao anexar blocks da linha '{name}': {r.text}")
                        time.sleep(1)
                except Exception as e:
                    print(f"[EXC] Exceção ao anexar blocks da linha '{name}': {e}")
                    time.sleep(1)
    return page_id



# Builders de blocos Notion
def mk_p(t):
    return {
        "object": "block",
        "type": "paragraph",
        "paragraph": {
            "rich_text": [
                {
                    "type": "text",
                    "text": {"content": str(t)[:1900]}
                }
            ]
        }
    }


def mk_code(t):
    """
    Cria um bloco de código suportando textos grandes.
    Quebra o conteúdo em chunks de até ~1900 caracteres
    (limite seguro por rich_text do Notion) sem cortar o DAX.
    """
    if t is None:
        t = ""
    max_chunk = 1900
    chunks = []
    for i in range(0, len(t), max_chunk):
        chunk = t[i:i + max_chunk]
        if not chunk:
            continue
        chunks.append({
            "type": "text",
            "text": {"content": chunk}
        })

    if not chunks:
        chunks.append({
            "type": "text",
            "text": {"content": ""}
        })

    return {
        "object": "block",
        "type": "code",
        "code": {
            "language": "markdown",
            "rich_text": chunks
        }
    }


def mk_head(t, lvl=3):
    if lvl > 3:
        lvl = 3
    return {
        "object": "block",
        "type": f"heading_{lvl}",
        f"heading_{lvl}": {
            "rich_text": [
                {
                    "type": "text",
                    "text": {"content": str(t)[:1900]}
                }
            ]
        }
    }


def mk_li(t):
    return {
        "object": "block",
        "type": "bulleted_list_item",
        "bulleted_list_item": {
            "rich_text": [
                {
                    "type": "text",
                    "text": {"content": str(t)[:1900]}
                }
            ]
        }
    }


def mk_div():
    return {"object": "block", "type": "divider", "divider": {}}


def create_table_block(headers, rows):
    tb = {
        "object": "block",
        "type": "table",
        "table": {
            "table_width": len(headers),
            "has_column_header": True,
            "children": []
        }
    }
    tb["table"]["children"].append({
        "type": "table_row",
        "table_row": {
            "cells": [
                [{"type": "text", "text": {"content": str(h)[:1900]}}] for h in headers
            ]
        }
    })
    for r in rows:
        cells = [
            [{"type": "text", "text": {"content": str(c)[:1900]}}] for c in r
        ]
        tb["table"]["children"].append({
            "type": "table_row",
            "table_row": {"cells": cells}
        })
    return tb


def archive_old_entries(project_name):
    print("--- 2. Limpando Notion (arquivando versões antigas do projeto) ---")
    url = f"https://api.notion.com/v1/databases/{DATABASE_ID}/query"
    payload = {"filter": {"property": "Project Name", "title": {"equals": project_name}}}
    try:
        resp = requests.post(url, headers=HEADERS, json=payload)
        data = resp.json()
        for p in data.get("results", []):
            requests.patch(
                f"https://api.notion.com/v1/pages/{p['id']}",
                headers=HEADERS,
                json={"archived": True}
            )
    except Exception as e:
        print(f"[AVISO] Falha ao arquivar entradas antigas no Notion: {e}")


# ==============================================================================
# 3. BUILDER
# ==============================================================================

# ==============================================================================
# SUPORTE PARA VOLUMETRIA (TABLE STORAGE) A PARTIR DO CSV GERADO PELO MINERADOR
# ==============================================================================
def load_table_storage_stats(config):
    """
    Lê o CSV de volumetria por tabela (table_storage_stats.csv) se existir.
    Espera colunas: table_name,row_count,columns_count,size_mb,model_size_pct,size_bucket
    Retorna dict indexado por nome de tabela.
    """
    # Caminho configurável, com fallback para padrão
    cfg_block = config.get("table_storage_from_vpax", {})
    path = config.get("table_storage_file") or cfg_block.get("output_csv") or "table_storage_stats.csv"

    if not os.path.exists(path):
        print(f"[INFO] Arquivo de volumetria não encontrado ({path}). DB 2 será criado sem métricas de storage.")
        return {}

    stats = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                name = (row.get("table_name") or "").strip()
                if not name:
                    continue
                stats[name] = row
    except Exception as e:
        print(f"[AVISO] Falha ao ler volumetria de tabelas em {path}: {e}")
        return {}

    print(f"[OK] Volumetria de tabelas carregada de {path} (total {len(stats)} registros).")
    return stats


def load_rls_members_from_csv():
    """
    Lê os CSVs exportados do DAX Studio (TMSCHEMA_ROLES e TMSCHEMA_ROLE_MEMBERSHIPS)
    se existirem na pasta atual.
    Espera arquivos nomeados como:
      - RLS_ROLES_*.csv
      - RLS_ROLE_MEMBERS_*.csv

    Retorna um dicionário:
      { role_name: [ {member_name, member_type, identity_provider, modified_time}, ... ] }

    Se não encontrar arquivos válidos, retorna {} e não quebra o fluxo.
    """
    roles_pattern = "RLS_ROLES_*.csv"
    members_pattern = "RLS_ROLE_MEMBERS_*.csv"

    roles_files = sorted(glob.glob(roles_pattern), key=os.path.getmtime, reverse=True)
    members_files = sorted(glob.glob(members_pattern), key=os.path.getmtime, reverse=True)

    if not roles_files or not members_files:
        print("[INFO] Arquivos de RLS (roles/members) não encontrados. DB 8 será criado sem lista de membros.")
        return {}

    roles_path = roles_files[0]
    members_path = members_files[0]

    def _open_with_delimiter(path):
        """Abre CSV detectando delimitador (; ou ,), com fallback em ;."""
        with open(path, "r", encoding="utf-8-sig") as f:
            sample = f.read(2048)
            f.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=";,")
                delim = dialect.delimiter
            except Exception:
                delim = ";"  # padrão mais comum no PT-BR
            reader = csv.DictReader(f, delimiter=delim)
            rows = [r for r in reader if r]
        return rows

    try:
        roles_rows = _open_with_delimiter(roles_path)
    except Exception as e:
        print(f"[AVISO] Falha ao ler {roles_path}: {e}")
        return {}

    role_id_to_name = {}
    for row in roles_rows:
        rid = (row.get("ID") or row.get("Id") or row.get("RoleID") or row.get("RoleId") or "").strip()
        rname = (row.get("Name") or row.get("RoleName") or "").strip()
        if rid and rname:
            role_id_to_name[rid] = rname

    if not role_id_to_name:
        print(f"[INFO] Nenhum mapeamento RoleID->Name encontrado em {roles_path}.")
        return {}

    try:
        members_rows = _open_with_delimiter(members_path)
    except Exception as e:
        print(f"[AVISO] Falha ao ler {members_path}: {e}")
        return {}

    members_by_role = {}
    total_links = 0
    for row in members_rows:
        rid = (row.get("RoleID") or row.get("RoleId") or "").strip()
        if not rid:
            continue
        rname = role_id_to_name.get(rid)
        if not rname:
            continue

        member_name = (row.get("MemberName") or "").strip()
        member_id = (row.get("MemberID") or "").strip()
        identity_provider = (row.get("IdentityProvider") or "").strip()
        member_type = (row.get("MemberType") or "").strip()
        modified_time = (row.get("ModifiedTime") or "").strip()

        display_name = member_name or member_id
        if not display_name:
            continue

        members_by_role.setdefault(rname, []).append({
            "member_name": display_name,
            "member_type": member_type,
            "identity_provider": identity_provider,
            "modified_time": modified_time
        })
        total_links += 1

    print(f"[OK] Membros de RLS carregados de CSV ({total_links} vínculos em {len(members_by_role)} roles).")
    return members_by_role





def load_column_volumetry_from_dmvs(config):
    """
    Lê os CSVs gerados pelo conector XMLA (DMVs) para volumetria por coluna.
    Espera arquivos com padrões:
      - table_storage_stats_*.csv
      - column_dictionary_stats_*.csv
      - tmschema_tables_*.csv
      - tmschema_columns_*.csv
      - tmschema_relationships_*.csv

    Retorna uma lista de dicts, cada um representando uma coluna com métricas:
      {
        "table_id": ...,
        "table_name": ...,
        "column_id": ...,
        "column_name": ...,
        "row_count": int | None,
        "dict_size": int | None,
        "dict_dtype": str,
        "is_key": bool,
        "is_hidden": bool,
        "is_nullable": bool,
        "display_folder": str,
        "in_relationship": bool,
      }

    Se não encontrar arquivos mínimos, retorna [] sem quebrar o fluxo.
    """
    base_dir = config.get("dmv_volumetry_dir") or "."

    def _latest(pattern):
        files = sorted(
            glob.glob(os.path.join(base_dir, pattern)),
            key=os.path.getmtime,
            reverse=True
        )
        return files[0] if files else None

    path_tables_storage = _latest("table_storage_stats_*.csv")
    path_col_dict = _latest("column_dictionary_stats_*.csv")
    path_tms_tables = _latest("tmschema_tables_*.csv")
    path_tms_cols = _latest("tmschema_columns_*.csv")
    path_tms_rels = _latest("tmschema_relationships_*.csv")

    required = [path_tables_storage, path_col_dict, path_tms_tables, path_tms_cols, path_tms_rels]
    if not all(required):
        print("[INFO] Arquivos de volumetria (DMVs XMLA) não encontrados de forma completa. DB 9 não será populado.")
        return []

    def _read_csv(path, detect_delim=False):
        with open(path, "r", encoding="utf-8-sig") as f:
            if detect_delim:
                sample = f.read(2048)
                f.seek(0)
                try:
                    dialect = csv.Sniffer().sniff(sample, delimiters=";,")
                    delim = dialect.delimiter
                except Exception:
                    delim = ","
            else:
                delim = ","
            reader = csv.DictReader(f, delimiter=delim)
            return [r for r in reader if r]

    try:
        rows_storage = _read_csv(path_tables_storage)
        rows_dict = _read_csv(path_col_dict)
        rows_tms_tables = _read_csv(path_tms_tables)
        rows_tms_cols = _read_csv(path_tms_cols)
        rows_tms_rels = _read_csv(path_tms_rels)
    except Exception as e:
        print(f"[AVISO] Falha ao ler arquivos de volumetria DMVs: {e}")
        return []

    # Mapa TABLE_ID -> TABLE_NAME
    table_id_to_name = {}
    for r in rows_tms_tables:
        tid = (r.get("TABLE_ID") or "").strip()
        tname = (r.get("TABLE_NAME") or "").strip()
        if tid and tname:
            table_id_to_name[tid] = tname

    # Mapa TABLE_NAME -> row_count (maior ROWS_COUNT encontrado por DIMENSION_NAME)
    table_rows_by_name = {}
    for r in rows_storage:
        dim = (r.get("DIMENSION_NAME") or "").strip()
        if not dim:
            continue
        try:
            rc = int(r.get("ROWS_COUNT") or 0)
        except Exception:
            rc = 0
        cur = table_rows_by_name.get(dim)
        if cur is None or rc > cur:
            table_rows_by_name[dim] = rc

    # Mapa (table_name, column_name) -> (dict_size, dict_dtype)
    dict_by_table_col = {}
    for r in rows_dict:
        dim = (r.get("DIMENSION_NAME") or "").strip()
        attr = (r.get("ATTRIBUTE_NAME") or "").strip()
        if not dim or not attr:
            continue
        try:
            dsz = int(r.get("DICTIONARY_SIZE") or 0)
        except Exception:
            dsz = 0
        dtype = (r.get("DATATYPE") or "").strip()
        dict_by_table_col[(dim, attr)] = (dsz, dtype)

    # Conjunto de colunas que participam de relacionamento
    rel_cols = set()
    for r in rows_tms_rels:
        ftid = (r.get("FromTableID") or "").strip()
        fcid = (r.get("FromColumnID") or "").strip()
        ttid = (r.get("ToTableID") or "").strip()
        tcid = (r.get("ToColumnID") or "").strip()
        if ftid and fcid:
            rel_cols.add((ftid, fcid))
        if ttid and tcid:
            rel_cols.add((ttid, tcid))

    result = []
    for r in rows_tms_cols:
        tid = (r.get("TABLE_ID") or "").strip()
        cid = (r.get("COLUMN_ID") or "").strip()
        if not tid or not cid:
            continue

        explicit_name = (r.get("EXPLICIT_NAME") or "").strip()
        inferred_name = (r.get("INFERRED_NAME") or "").strip()
        col_name = explicit_name or inferred_name or f"Column_{cid}"

        table_name = table_id_to_name.get(tid, "")
        row_count = table_rows_by_name.get(table_name)

        # Flags
        def _parse_bool(val):
            s = (str(val) or "").strip().lower()
            return s in ("true", "1", "yes", "y")

        is_hidden = _parse_bool(r.get("IsHidden"))
        is_key = _parse_bool(r.get("IsKey"))
        is_nullable = _parse_bool(r.get("IsNullable"))
        display_folder = (r.get("DisplayFolder") or "").strip()

        dict_size = None
        dict_dtype = ""
        if table_name and col_name:
            dkey = (table_name, col_name)
            if dkey in dict_by_table_col:
                dict_size, dict_dtype = dict_by_table_col[dkey]

        in_rel = (tid, cid) in rel_cols

        result.append({
            "table_id": tid,
            "table_name": table_name,
            "column_id": cid,
            "column_name": col_name,
            "row_count": row_count,
            "dict_size": dict_size,
            "dict_dtype": dict_dtype,
            "is_key": is_key,
            "is_hidden": is_hidden,
            "is_nullable": is_nullable,
            "display_folder": display_folder,
            "in_relationship": in_rel,
        })

    print(f"[OK] Volumetria de colunas (DMVs) carregada ({len(result)} colunas).")
    return result


def build_structure(config, structure):
    print("--- 3. Construindo V28 (Final + IA + Visual Label + Big DAX) ---")
    t_total_start = time.time()
    table_stats = load_table_storage_stats(config)
    column_vol_stats = load_column_volumetry_from_dmvs(config)

    # Cria a capa do projeto
    url = "https://api.notion.com/v1/pages"

    # Normaliza o project_link: string vazia vira None (null no JSON)
    raw_project_link = config.get("project_link")
    if isinstance(raw_project_link, str):
        raw_project_link = raw_project_link.strip()
        if raw_project_link == "":
            raw_project_link = None

    properties = {
        "Project Name": {
            "title": [
                {
                    "text": {
                        "content": config["project_name"]
                    }
                }
            ]
        },
        "Last Update": {
            "date": {
                "start": datetime.now().strftime("%Y-%m-%d")
            }
        }
    }

    # Só define Project Link se houver valor (evita erro de validação com string vazia)
    if raw_project_link is not None:
        properties["Project Link"] = {"url": raw_project_link}

    payload = {
        "parent": {"database_id": DATABASE_ID},
        "properties": properties
    }

    resp = requests.post(url, headers=HEADERS, json=payload)
    if resp.status_code != 200:
        print("--- ERRO ao criar capa no Notion ---")
        print("Status:", resp.status_code)
        try:
            data = resp.json()
            print("Resposta:", data)
        except Exception:
            print("Resposta bruta:", resp.text)
        sys.exit(1)

    data = resp.json()
    main_id = data["id"]
    print("> Capa criada.")

    # Cria DB Mestre de módulos logo abaixo da capa
    master_db_id = create_inline_db(
        main_id,
        "Modules",
        {
            "Module": {"title": {}},
            "Summary": {"rich_text": {}}
        }
    )
    if not master_db_id:
        print("[AVISO] Não foi possível criar o DB Mestre 'Modules'. Os módulos serão criados diretamente abaixo da capa.")
    else:
        print("> DB Mestre 'Modules' criado.")


    unified_pages = structure.get("unified_pages", {})

    # Mapa NomeMedida -> ID global, para usar na coluna "ID Medidas"
    measure_name_to_id = {
        m["name"]: m.get("global_id", "")
        for m in structure.get("measures", [])
    }

    # 1. Conexões DB
    print("> DB 1: Conexões DB")
    t_db7_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_conn_parent = main_id
    if master_db_id:
        conn_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "1. Conexões DB"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Detalhamento das conexões de dados (Power Query / M) do modelo."}}]}
            },
            [],
            "1. Conexões DB"
        )
        if conn_module_page_id:
            module_conn_parent = conn_module_page_id

    db_conn = create_inline_db(module_conn_parent, "1. Conexões DB", {
        "Nome Tabela": {"title": {}},
        "Fonte": {"rich_text": {}},
        "Projeto / Servidor": {"rich_text": {}},
        "Dataset / Schema": {"rich_text": {}},
        "Objeto": {"rich_text": {}}
    })

    if db_conn:
        for conn in structure.get("connections", []):
            t_name = conn.get("table", "")
            fonte = conn.get("source_type", "")
            projeto = conn.get("project", "")
            dataset = conn.get("dataset", "")
            obj = conn.get("object", "")
            m_expr = (conn.get("m_expression") or "").strip()

            body = [
                mk_head("Detalhes da Conexão", 3),
                mk_p(f"Fonte: {fonte}"),
                mk_p(f"Projeto/Servidor: {projeto}"),
                mk_p(f"Dataset/Schema: {dataset}"),
                mk_p(f"Objeto: {obj}"),
                mk_div(),
                mk_head("M Code (Consulta)", 3),
                mk_code(m_expr or "// M code não capturado automaticamente.")
            ]

            add_row_heavy(
                db_conn,
                {
                    "Nome Tabela": {"title": [{"text": {"content": t_name}}]},
                    "Fonte": {"rich_text": [{"text": {"content": fonte}}]},
                    "Projeto / Servidor": {"rich_text": [{"text": {"content": projeto}}]},
                    "Dataset / Schema": {"rich_text": [{"text": {"content": dataset}}]},
                    "Objeto": {"rich_text": [{"text": {"content": obj}}]}
                },
                body,
                t_name or fonte
            )


    elapsed_db7 = time.time() - t_db7_start
    print(f"Tempo da etapa 'DB 1 - Conexões DB': {elapsed_db7/60:.1f} minutos.")

    # 2. TABELAS
    print("> DB 2: Tabelas")
    t_db2_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_tables_parent = main_id
    if master_db_id:
        tables_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "2. Tabelas"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Lista das tabelas do modelo, com contagem de colunas e volumetria básica."}}]}
            },
            [],
            "2. Tabelas"
        )
        if tables_module_page_id:
            module_tables_parent = tables_module_page_id

    db_tbl = create_inline_db(module_tables_parent, "2. Tabelas", {
        "Nome": {"title": {}},
        "Qtd Colunas": {"number": {}},
        "Qtd Col Calculadas": {"number": {}},
        "Qtd Col Físicas": {"number": {}},
        "Row Count": {"number": {}},
        "Size (MB)": {"number": {}},
        "% Modelo": {"number": {}},
        "Bucket Tamanho": {"select": {}}
    })
    IGNORE = ["_DAX", "_DAX_AUDIT", "DAX", "_TEST"]
    if db_tbl:
        for t_name, t_data in sorted(structure.get("tables", {}).items()):
            if any(ign in t_name for ign in IGNORE):
                continue
            body = []
            cols = t_data.get("columns", [])
            if cols:
                body.append(mk_p(f"Colunas ({len(cols)}):"))
                h = ["Coluna", "Origem", "Tipo"]
                rs = [
                    [c["name"], c.get("origin", "Física"), c["type"]]
                    for c in cols
                ]
                if len(rs) > 90:
                    rs = rs[:90]
                body.append(create_table_block(h, rs))
            total_cols = len(cols)
            calc_cols = sum(1 for c in cols if c.get("origin") == "Calculada (DAX)")
            phys_cols = total_cols - calc_cols

            # Enriquecimento com volumetria (se disponível)
            ts = table_stats.get(t_name) if table_stats else None
            row_count_val = None
            size_mb_val = None
            pct_model_val = None
            bucket_val = None
            if ts:
                try:
                    row_count_val = int(ts.get("row_count") or 0)
                except Exception:
                    row_count_val = None
                try:
                    size_mb_val = float(ts.get("size_mb") or 0)
                except Exception:
                    size_mb_val = None
                try:
                    pct_model_val = float(ts.get("model_size_pct") or 0)
                except Exception:
                    pct_model_val = None
                bucket_val = (ts.get("size_bucket") or "").strip() or None

            props = {
                "Nome": {"title": [{"text": {"content": t_name}}]},
                "Qtd Colunas": {"number": total_cols},
                "Qtd Col Calculadas": {"number": calc_cols},
                "Qtd Col Físicas": {"number": phys_cols},
            }
            if row_count_val is not None:
                props["Row Count"] = {"number": row_count_val}
            if size_mb_val is not None:
                props["Size (MB)"] = {"number": size_mb_val}
            if pct_model_val is not None:
                props["% Modelo"] = {"number": pct_model_val}
            if bucket_val is not None:
                props["Bucket Tamanho"] = {"select": {"name": bucket_val}}

            add_row_heavy(
                db_tbl,
                props,
                body,
                t_name
            )


    elapsed_db2 = time.time() - t_db2_start
    print(f"Tempo da etapa 'DB 2 - Tabelas': {elapsed_db2/60:.1f} minutos.")

    # 3. Volumetria por Coluna (DMVs XMLA)
    print("> DB 3: Volumetria por Coluna (DMVs XMLA)")
    t_db9_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_vol_cols_parent = main_id
    if master_db_id:
        vol_cols_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "3. Volumetria Colunas"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Volumetria de colunas via DMVs XMLA, incluindo dicionário e participação em relacionamentos."}}]}
            },
            [],
            "3. Volumetria Colunas"
        )
        if vol_cols_module_page_id:
            module_vol_cols_parent = vol_cols_module_page_id

    db_vol_tabs = create_inline_db(module_vol_cols_parent, "3. Volumetria Colunas", {
        "Tabela": {"title": {}},
        "Row Count": {"number": {}},
        "Hidden": {"select": {}}
    })

    if db_vol_tabs and column_vol_stats:
        # Agrupa colunas por tabela
        tables_map = {}
        for col in column_vol_stats:
            tname = (col.get("table_name") or "").strip()
            cname = (col.get("column_name") or "").strip()
            if not tname or not cname:
                continue
            # Pula colunas internas RowNumber-<GUID>
            if cname.lower().startswith("rownumber-"):
                continue
            tinfo = tables_map.setdefault(tname, {
                "row_count": col.get("row_count"),
                "table_hidden": col.get("table_hidden", False),
                "columns": []
            })
            rc = col.get("row_count")
            if rc is not None:
                cur_rc = tinfo.get("row_count")
                if cur_rc is None or rc > cur_rc:
                    tinfo["row_count"] = rc
            if col.get("table_hidden") is True:
                tinfo["table_hidden"] = True
            tinfo["columns"].append(col)

        def _yes_no(flag):
            return "Sim" if flag else "Não"

        def _translate_dtype(dtype_raw: str) -> str:
            if not dtype_raw:
                return ""
            raw = str(dtype_raw).strip()
            up = raw.upper()
            # Se já vier amigável, não mexe
            if not up.startswith("DBTYPE_"):
                return raw
            if up in ("DBTYPE_R4", "DBTYPE_R8", "DBTYPE_NUMERIC", "DBTYPE_DECIMAL"):
                return "Decimal"
            if up in (
                "DBTYPE_I1", "DBTYPE_I2", "DBTYPE_I4", "DBTYPE_I8",
                "DBTYPE_UI1", "DBTYPE_UI2", "DBTYPE_UI4", "DBTYPE_UI8",
            ):
                return "Integer"
            if up in ("DBTYPE_WSTR", "DBTYPE_STR", "DBTYPE_BSTR", "DBTYPE_WCHAR"):
                return "Text"
            if "DATE" in up or "TIME" in up:
                return "Date/Time"
            if up in ("DBTYPE_BOOL", "DBTYPE_BOOLEAN"):
                return "Boolean"
            if up in ("DBTYPE_CY", "DBTYPE_CURRENCY"):
                return "Currency"
            return raw

        for tname in sorted(tables_map.keys()):
            tinfo = tables_map[tname]
            row_count_val = tinfo.get("row_count")
            hidden_flag = tinfo.get("table_hidden", False)

            # DB externo: uma linha por tabela
            props_table = {
                "Tabela": {"title": [{"text": {"content": tname}}]},
                "Hidden": {"select": {"name": _yes_no(hidden_flag)}},
            }
            if row_count_val is not None:
                props_table["Row Count"] = {"number": row_count_val}

            table_page_id = add_row_heavy(
                db_vol_tabs,
                props_table,
                [],
                tname
            )
            if not table_page_id:
                continue

            # DB interno "Detalhamento" por tabela
            det_db_id = create_inline_db(table_page_id, "Detalhamento", {
                "Coluna": {"title": {}},
                "Datatype (Dict)": {"rich_text": {}},
                "Dictionary Size": {"number": {}},
                "Em Relacionamento?": {"select": {}},
            })
            if not det_db_id:
                continue

            cols_sorted = sorted(
                tinfo["columns"],
                key=lambda c: (c.get("column_name") or "").lower()
            )

            prefix = f"{tname}."
            for col in cols_sorted:
                raw_col_name = (col.get("column_name") or "").strip()
                display_name = raw_col_name
                # Limpa prefixo Tabela. quando for exatamente o nome da tabela
                if raw_col_name.startswith(prefix):
                    display_name = raw_col_name[len(prefix):]

                dtype_disp = _translate_dtype(col.get("dict_dtype") or "")
                dict_size = col.get("dict_size")

                props_col = {
                    "Coluna": {"title": [{"text": {"content": display_name[:1800]}}]},
                    "Datatype (Dict)": {"rich_text": [{"text": {"content": dtype_disp}}]},
                    "Dictionary Size": {"number": dict_size},
                    "Em Relacionamento?": {"select": {"name": _yes_no(col.get("in_relationship"))}},
                }

                add_row_heavy(
                    det_db_id,
                    props_col,
                    [],
                    display_name
                )

    elapsed_db9 = time.time() - t_db9_start
    print(f"Tempo da etapa 'DB 3 - Volumetria Colunas': {elapsed_db9/60:.1f} minutos.")
    # 4. DAX Tabelas (Colunas Calculadas)
    print("> DB 4: Medidas DAX Tabelas (Colunas Calculadas)")
    t_db6_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_dax_cols_parent = main_id
    if master_db_id:
        dax_cols_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "4. Medidas DAX Tabelas"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Colunas calculadas em DAX nas tabelas do modelo."}}]}
            },
            [],
            "4. Medidas DAX Tabelas"
        )
        if dax_cols_module_page_id:
            module_dax_cols_parent = dax_cols_module_page_id

    db_dax_cols = create_inline_db(module_dax_cols_parent, "4. Medidas DAX Tabelas", {
        "Nome Coluna": {"title": {}},
        "Tabela": {"rich_text": {}}
    })

    if db_dax_cols:
        for t_name, t_data in sorted(structure.get("tables", {}).items()):
            cols = t_data.get("columns", [])
            for c in cols:
                if c.get("origin") != "Calculada (DAX)":
                    continue
                expr = (c.get("expression_dax") or "").strip()
                body = [
                    mk_head("Tabela", 3),
                    mk_p(t_name),
                    mk_div(),
                    mk_head("Código DAX", 3),
                    mk_code(expr or "// Expressão DAX não capturada automaticamente.")
                ]
                add_row_heavy(
                    db_dax_cols,
                    {
                        "Nome Coluna": {"title": [{"text": {"content": c.get("name", "")}}]},
                        "Tabela": {"rich_text": [{"text": {"content": t_name}}]}
                    },
                    body,
                    f"{t_name}.{c.get('name', '')}"
                )


    elapsed_db6 = time.time() - t_db6_start
    print(f"Tempo da etapa 'DB 4 - Medidas DAX Tabelas': {elapsed_db6/60:.1f} minutos.")

    # 5. RELACIONAMENTOS
    print("> DB 5: Relacionamentos")
    t_db1_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_rels_parent = main_id
    if master_db_id:
        rels_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "5. Relacionamentos"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Relacionamentos entre tabelas, cardinalidade, direção de filtro e status de ativação."}}]}
            },
            [],
            "5. Relacionamentos"
        )
        if rels_module_page_id:
            module_rels_parent = rels_module_page_id

    db_rel = create_inline_db(module_rels_parent, "5. Relacionamentos", {
        "ID": {"title": {}},
        "De": {"rich_text": {}},
        "Para": {"rich_text": {}},
        "Cardinalidade": {"select": {}},
        "Direção": {"select": {}},
        "Ativa?": {"select": {}}
    })
    if db_rel:
        for i, r in enumerate(structure.get("relationships", [])):
            add_row_heavy(
                db_rel,
                {
                    "ID": {"title": [{"text": {"content": f"R{i + 1}"}}]},
                    "De": {"rich_text": [{"text": {"content": r.get("from", "?")}}]},
                    "Para": {"rich_text": [{"text": {"content": r.get("to", "?")}}]},
                    "Cardinalidade": {"select": {"name": r.get("cardinality", "-")}},
                    "Direção": {"select": {"name": r.get("filter", "-")}},
                    "Ativa?": {"select": {"name": r.get("active", "-")}}
                },
                []
            )


    elapsed_db1 = time.time() - t_db1_start
    print(f"Tempo da etapa 'DB 5 - Relacionamentos': {elapsed_db1/60:.1f} minutos.")

    # 6. PÁGINAS (UNIFICADAS, COM VISUAL LABEL + ID Medidas EM DB INLINE)
    print("> DB 6: Páginas do Relatório (Unified + Inline Detalhamento DB)")
    t_db3_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_pages_parent = main_id
    if master_db_id:
        pages_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "6. Páginas do Relatório"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Páginas do relatório, visuais e vínculo com medidas (estrutura unificada com detalhamento inline."}}]}
            },
            [],
            "6. Páginas do Relatório"
        )
        if pages_module_page_id:
            module_pages_parent = pages_module_page_id

    db_pg = create_inline_db(module_pages_parent, "6. Páginas do Relatório", {
        "Página": {"title": {}},
        "Qtd Visuais": {"number": {}}
    })

    if db_pg:
        for p_name, vis_list in sorted(unified_pages.items()):
            # Cria a linha da página no DB 6
            page_props = {
                "Página": {"title": [{"text": {"content": p_name}}]},
                "Qtd Visuais": {"number": len(vis_list)}
            }
            page_id = add_row_heavy(
                db_pg,
                page_props,
                [],
                p_name
            )

            if not page_id:
                continue

            # Dentro de cada página, criamos um DB inline específico para o detalhamento dos visuais
            detalhamento_props = {
                "Visual Label": {"title": {}},
                "Tipo Visual": {"select": {}},
                "Qtd": {"number": {}},
                "ID Medidas": {"rich_text": {}}
            }
            detalhamento_db_id = create_inline_db(page_id, "Detalhamento", detalhamento_props)

            if not detalhamento_db_id:
                continue

            # Popula o DB de Detalhamento desta página
            for v in vis_list:
                m_names = v.get("measures", [])
                m_len = len(m_names)

                # Converte nomes das medidas em IDs globais (M001, M002, ...)
                m_ids = []
                for m_name in m_names:
                    mid = measure_name_to_id.get(m_name, "")
                    if mid:
                        m_ids.append(mid)
                m_str_ids = ", ".join(m_ids)

                raw_label = v.get("label", "") or ""
                # Título não pode ser vazio; se não houver label, usa tipo + contagem
                safe_label = raw_label.strip() or f"{v.get('type', 'Visual Desconhecido')} ({m_len} medidas)"

                vis_props = {
                    "Visual Label": {"title": [{"text": {"content": safe_label[:1800]}}]},
                    "Tipo Visual": {"select": {"name": v.get("type", "Visual Desconhecido")}},
                    "Qtd": {"number": m_len},
                    "ID Medidas": {"rich_text": [{"text": {"content": m_str_ids}}]}
                }

                add_row_heavy(
                    detalhamento_db_id,
                    vis_props,
                    [],
                    safe_label
                )



    elapsed_db3 = time.time() - t_db3_start
    print(f"Tempo da etapa 'DB 6 - Páginas do Relatório': {elapsed_db3/60:.1f} minutos.")

    # 7. VISUAIS (Agrupados por Tipo)
    print("> DB 7: Tipos de Visuais")
    t_db4_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_visuals_parent = main_id
    if master_db_id:
        visuals_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "7. Visuais Detalhados"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Tipos de visuais e distribuição nas páginas do relatório."}}]}
            },
            [],
            "7. Visuais Detalhados"
        )
        if visuals_module_page_id:
            module_visuals_parent = visuals_module_page_id

    db_vis = create_inline_db(module_visuals_parent, "7. Visuais Detalhados", {
        "Tipo": {"title": {}},
        "Qtd Páginas": {"number": {}}
    })

    type_map = {}
    for p_name, v_list in unified_pages.items():
        for v in v_list:
            vt = v.get("type", "Visual Desconhecido")
            if vt not in type_map:
                type_map[vt] = set()
            type_map[vt].add(p_name)

    if db_vis:
        for v_type, pages in type_map.items():
            body = [mk_head("Presente nas Páginas:", 3)]
            for pg in sorted(list(pages)):
                body.append(mk_li(pg))

            add_row_heavy(
                db_vis,
                {
                    "Tipo": {"title": [{"text": {"content": v_type}}]},
                    "Qtd Páginas": {"number": len(pages)}
                },
                body,
                v_type
            )


    elapsed_db4 = time.time() - t_db4_start
    print(f"Tempo da etapa 'DB 7 - Tipos de Visuais': {elapsed_db4/60:.1f} minutos.")

    # 8. DAX
    print("> DB 8: Medidas DAX")
    t_db5_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_measures_parent = main_id
    if master_db_id:
        measures_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "8. Medidas DAX"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Catálogo das medidas DAX, código, descrições, dependências e uso em visuais."}}]}
            },
            [],
            "8. Medidas DAX"
        )
        if measures_module_page_id:
            module_measures_parent = measures_module_page_id

    db_dax = create_inline_db(module_measures_parent, "8. Medidas DAX", {
        "Nome": {"title": {}},
        "ID": {"rich_text": {}},
        "Status": {"select": {}},
        "Visual?": {"select": {}}
    })

    if db_dax:
        total = len(structure.get("measures", []))
        for i, m in enumerate(structure.get("measures", [])):
            status = m.get("status", "Analise")

            # Sanitiza o nome da medida para evitar erros no Notion
            raw_name = (m.get("name") or "").strip()
            if not raw_name:
                safe_name = f"[Unnamed Measure {m.get('global_id', '')}]".strip()
            else:
                # Evita títulos excessivamente longos
                safe_name = raw_name[:1800]


            body = [
                mk_head("📖 Descrição", 3),
                mk_p(m.get("desc", "")),
                mk_div(),
                mk_head("💻 Código DAX", 3),
                mk_code(m.get("dax", "")),
                mk_div(),
                mk_head("📄 Uso em Visuais", 3)
            ]

            found_in_pages = []
            for p_name, v_list in unified_pages.items():
                for v in v_list:
                    if m["name"] in v.get("measures", []):
                        found_in_pages.append(f"Pág: {p_name} | {v.get('type', 'Visual')} | {v.get('label', '')}")

            if found_in_pages:
                for fp in sorted(list(set(found_in_pages))):
                    body.append(mk_li(fp))
            else:
                body.append(mk_p("Sem uso direto."))

            body.append(mk_div())
            body.append(mk_head("🔗 Pais", 3))
            if m.get("parent_names"):
                for x in m.get("parent_names"):
                    body.append(mk_li(x))
            else:
                body.append(mk_p("-"))

            body.append(mk_head("🌲 Filhos", 3))
            if m.get("child_names"):
                for x in m.get("child_names"):
                    body.append(mk_li(x))
            else:
                body.append(mk_p("-"))

            time.sleep(0.1)
            add_row_heavy(
                db_dax,
                {
                    "Nome": {"title": [{"text": {"content": safe_name}}]},
                    "ID": {"rich_text": [{"text": {"content": m.get("global_id", "")}}]},
                    "Status": {"select": {"name": status}},
                    "Visual?": {"select": {"name": m.get("visual_text", "")}}
                },
                body,
                m["name"]
            )

            if (i + 1) % 50 == 0:
                print(f"  - {i + 1}/{total} medidas enviadas para o Notion...")




    elapsed_db5 = time.time() - t_db5_start
    print(f"Tempo da etapa 'DB 8 - Medidas DAX': {elapsed_db5/60:.1f} minutos.")

    # 9. RLS (Row-Level Security)
    print("> DB 9: RLS (Row-Level Security)")
    t_db8_start = time.time()

    # Cria linha do módulo no DB Mestre (se existir)
    module_rls_parent = main_id
    if master_db_id:
        rls_module_page_id = add_row_heavy(
            master_db_id,
            {
                "Module": {"title": [{"text": {"content": "9. RLS"}}]},
                "Summary": {"rich_text": [{"text": {"content": "Configuração de RLS: roles, filtros por tabela e membros no Power BI Service."}}]}
            },
            [],
            "9. RLS"
        )
        if rls_module_page_id:
            module_rls_parent = rls_module_page_id

    db_rls = create_inline_db(module_rls_parent, "9. RLS", {
        "Role Name": {"title": {}},
        "Qtd Tabelas": {"number": {}},
        "Qtd Usuários": {"number": {}}
    })

    # Membros de RLS vindos dos CSVs exportados via DAX Studio (opcional)
    rls_members_by_role = load_rls_members_from_csv()

    roles = structure.get("roles", [])
    if db_rls and roles:
        for role in roles:
            rname = role.get("name", "")
            tables = role.get("tables", [])
            body = [mk_head("Tabelas e Regras", 3)]
            if tables:
                for t in tables:
                    tname = t.get("table", "")
                    fdax = (t.get("filter_dax") or "").strip()
                    body.append(mk_head(tname, 3))
                    if fdax:
                        body.append(mk_code(fdax))
                    else:
                        body.append(mk_p("Sem filtro definido."))
            else:
                body.append(mk_p("Role sem tabelas associadas."))

            # Bloco adicional: Membros associados à role no Power BI Service
            members = rls_members_by_role.get(rname, [])
            body.append(mk_div())
            body.append(mk_head("Membros (Power BI Service)", 3))
            if members:
                headers = ["Email", "MemberType", "IdentityProvider", "Última Atribuição"]
                rows = []
                for mem in members:
                    rows.append([
                        (mem.get("member_name") or "").strip(),
                        (mem.get("member_type") or "").strip(),
                        (mem.get("identity_provider") or "").strip(),
                        (mem.get("modified_time") or "").strip(),
                    ])
                body.append(create_table_block(headers, rows))
            else:
                body.append(mk_p("Nenhum membro encontrado a partir dos arquivos RLS_ROLE_MEMBERS_*.csv."))

            add_row_heavy(
                db_rls,
                {
                    "Role Name": {"title": [{"text": {"content": rname}}]},
                    "Qtd Tabelas": {"number": len(tables)},
                    "Qtd Usuários": {"number": len(members)}
                },
                body,
                rname
            )

    elapsed_db8 = time.time() - t_db8_start
    print(f"Tempo da etapa 'DB 9 - RLS': {elapsed_db8/60:.1f} minutos.")

    elapsed_total = time.time() - t_total_start
    print(f"Tempo TOTAL da etapa 'Build completo (DB 1-9)': {elapsed_total/60:.1f} minutos.")



    print("\nSUCESSO TOTAL!")


if __name__ == "__main__":
    conf, struct = load_data()
    archive_old_entries(conf["project_name"])
    build_structure(conf, struct)