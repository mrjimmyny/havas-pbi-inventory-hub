# -*- coding: utf-8 -*-
import os
import sys
import requests
import time
import json
import re
from pathlib import Path


# ==============================================================================
# UTF-8 SAFE STDOUT/STDERR (Windows / PyInstaller)
# ==============================================================================
def _force_utf8_stdio() -> None:
    """
    Garante que prints/logs não quebrem em Windows (cp1252) quando houver Unicode.
    - Força UTF-8 (quando possível)
    - E usa 'backslashreplace' para nunca dar UnicodeEncodeError
    """
    try:
        import os as _os
        import sys as _sys
        _os.environ.setdefault("PYTHONIOENCODING", "utf-8")
        _os.environ.setdefault("PYTHONUTF8", "1")
        if hasattr(_sys.stdout, "reconfigure"):
            _sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
        if hasattr(_sys.stderr, "reconfigure"):
            _sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:
        pass

_force_utf8_stdio()

"""
Script: notion_post_links_ids.py

Objetivo
--------
Pós-processar o HUB de Documentação no Notion para transformar todos os IDs de medidas
(M001, M002, ...) que aparecem na coluna "ID Medidas" do banco:

    6. Páginas do Relatório (Unified + Label + IDs)

em links clicáveis que apontam diretamente para as páginas das medidas no banco:

    8. Medidas DAX

A ideia é simples:
- Ler todas as medidas no DB "8. Medidas DAX" e montar um mapa ID -> URL.
- Ler todas as páginas do DB "6. Páginas do Relatório", localizar tabelas com a coluna "ID Medidas".
- Em cada linha, reconstruir completamente o conteúdo da coluna "ID Medidas"
  substituindo cada ID reconhecido por um link clicável para a página da medida.
O script é idempotente: pode ser rodado várias vezes sem quebrar nada.
"""

# ==============================================================================
# CONFIGURAÇÕES
# ==============================================================================

def load_notion_config() -> dict:
    """
    Carrega configurações do Notion a partir de notion_config.json localizado
    na mesma pasta do executável (.exe) ou do script .py.
    """
    if getattr(sys, "frozen", False):
        base_dir = Path(sys.executable).resolve().parent
    else:
        base_dir = Path(__file__).resolve().parent

    config_path = base_dir / "notion_config.json"

    if not config_path.is_file():
        print(f"[ERRO] Arquivo 'notion_config.json' não encontrado em: {config_path}")
        print("       Crie e configure esse arquivo antes de rodar esta etapa (V5 - Notion Post Links).")
        sys.exit(1)

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[ERRO] Falha ao ler/parsear 'notion_config.json': {e}")
        sys.exit(1)

    token = data.get("notion_api_key") or ""
    if not token:
        print("[ERRO] Campo 'notion_api_key' ausente ou vazio em notion_config.json.")
        sys.exit(1)

    databases = data.get("databases") or {}
    hub_db_id = databases.get("pbi_inventory_hub") or ""
    if not hub_db_id:
        print("[ERRO] Campo 'databases.pbi_inventory_hub' ausente ou vazio em notion_config.json.")
        print("       Mesmo que este script não use diretamente esse ID, ele é obrigatório para o framework.")
        sys.exit(1)

    return {
        "token": token,
        "hub_database_id": hub_db_id,
        "raw": data,
        "config_path": str(config_path),
    }


_config = load_notion_config()
NOTION_TOKEN = _config["token"]

_raw_cfg = _config["raw"]
_options = _raw_cfg.get("options") or {}
ENABLE_MEASURE_LINKS = _options.get("enable_measure_links", True)

if not ENABLE_MEASURE_LINKS:
    print("[AVISO] options.enable_measure_links = false em notion_config.json.")
    print("   Etapa V5 - Notion Post Links será ignorada.")
    sys.exit(0)

HEADERS = {
    "Authorization": f"Bearer {NOTION_TOKEN}",
    "Content-Type": "application/json",
    "Notion-Version": "2022-06-28",
}

# Nomes exatos dos bancos criados pelo constructor
DB5_NAME = "8. Medidas DAX"
DB3_NAME = "6. Páginas do Relatório"


# ==============================================================================
# HELPERS NOTION (REQUESTS COM RETRY BÁSICO)
# ==============================================================================

def _notion_request(method: str, url: str, **kwargs) -> requests.Response:
    """
    Wrapper básico para chamadas à API do Notion com:
    - headers padrão
    - até 3 tentativas
    - tratamento de 429 (rate limit)
    - devolve o último Response recebido
    """
    for attempt in range(3):
        if "headers" in kwargs:
            hdrs = dict(HEADERS)
            hdrs.update(kwargs["headers"])
            kwargs["headers"] = hdrs
        else:
            kwargs["headers"] = HEADERS

        resp = requests.request(method, url, **kwargs)

        if resp.status_code == 429:
            # rate limit -> espera um pouco e tenta de novo
            time.sleep(5)
            continue

        if resp.status_code in (200, 400, 404):
            return resp

        # pequeno backoff para outros erros transitórios
        time.sleep(1)

    return resp


def notion_post(url: str, payload: dict) -> requests.Response:
    return _notion_request("post", url, json=payload)


def notion_get(url: str, params: dict | None = None) -> requests.Response:
    return _notion_request("get", url, params=params or {})


def notion_patch(url: str, payload: dict) -> requests.Response:
    return _notion_request("patch", url, json=payload)


# ==============================================================================
# BUSCA DE DATABASE POR TÍTULO
# ==============================================================================

def search_database_by_title(db_title: str) -> str | None:
    """
    Usa o endpoint /v1/search para localizar o database cujo título bate
    exatamente com db_title. Retorna o ID do database ou None.
    """
    url = "https://api.notion.com/v1/search"
    payload = {
        "query": db_title,
        "filter": {
            "property": "object",
            "value": "database",
        },
        "page_size": 50,
    }

    r = notion_post(url, payload)
    if r.status_code != 200:
        print(f"[ERRO] Erro ao buscar database '{db_title}': {r.status_code} - {r.text}")
        return None

    data = r.json()
    results = data.get("results", [])

    for db in results:
        title_arr = db.get("title", [])
        title = "".join(t.get("plain_text", "") for t in title_arr).strip()
        if title == db_title:
            print(f"[OK] Database '{db_title}' encontrado: {db.get('id')}")
            return db.get("id")

    print(f"[ERRO] Database '{db_title}' não encontrado via search().")
    return None


# ==============================================================================
# QUERY PAGINADO EM DATABASE
# ==============================================================================

def query_all_pages(db_id: str) -> list[dict]:
    """
    Faz query paginada em um database Notion, retornando todas as páginas.
    """
    url = f"https://api.notion.com/v1/databases/{db_id}/query"
    all_results: list[dict] = []
    payload: dict = {}

    while True:
        r = notion_post(url, payload)
        if r.status_code != 200:
            print(f"[ERRO] Erro ao consultar database {db_id}: {r.status_code} - {r.text}")
            break

        data = r.json()
        all_results.extend(data.get("results", []))

        nxt = data.get("next_cursor")
        if not nxt:
            break
        payload["start_cursor"] = nxt

    return all_results


# ==============================================================================
# 3) MAPA ID MEDIDA -> URL PÁGINA (DB "8. Medidas DAX")
# ==============================================================================

def build_measure_id_to_url_map(db5_id: str) -> dict[str, str]:
    """
    Lê o database '5. Medidas DAX' e monta um mapa:
        { "M001": "https://www.notion.so/..." , ... }
    usando a propriedade "ID" e o campo "url" de cada página.
    """
    pages = query_all_pages(db5_id)
    mapping: dict[str, str] = {}

    print(f"[INFO] Construindo mapa ID -> URL a partir de {len(pages)} medidas...")

    for page in pages:
        props = page.get("properties", {})
        id_prop = props.get("ID", {})
        rich = id_prop.get("rich_text", [])
        if not rich:
            continue

        measure_id = rich[0].get("plain_text", "").strip()
        if not measure_id:
            continue

        url = page.get("url", "").strip()
        if not url:
            # fallback: monta URL manual usando o page_id
            pid = page.get("id", "")
            if pid:
                clean = pid.replace("-", "")
                url = f"https://www.notion.so/{clean}"

        if url:
            mapping[measure_id] = url

    print(f"[OK] Mapa ID->URL montado com {len(mapping)} entradas.")
    return mapping


# ==============================================================================
# 4) LEITURA DE BLOCOS (PÁGINAS / TABELAS)
# ==============================================================================

def get_block_children(block_id: str) -> list[dict]:
    """
    Lê todos os filhos de um bloco (paginação se necessário).
    """
    url = f"https://api.notion.com/v1/blocks/{block_id}/children"
    children: list[dict] = []
    params: dict = {"page_size": 100}

    while True:
        r = notion_get(url, params)
        if r.status_code != 200:
            print(f"[ERRO] Erro ao carregar filhos do bloco {block_id}: {r.status_code} - {r.text}")
            break

        data = r.json()
        children.extend(data.get("results", []))

        nxt = data.get("next_cursor")
        if not nxt:
            break
        params["start_cursor"] = nxt

    return children


# ==============================================================================
# 5) CONSTRUÇÃO DO RICH_TEXT COM LINKS A PARTIR DE UMA STRING
# ==============================================================================

ID_PATTERN = re.compile(r"M\d+")

def _make_text_segment(content: str, url: str | None = None) -> dict:
    """
    Cria um rich_text básico. Se url vier preenchido, vira link clicável.
    """
    seg: dict = {
        "type": "text",
        "text": {
            "content": content,
        },
    }
    if url:
        seg["text"]["link"] = {"url": url}
    return seg


def build_linked_rich_text(original_text: str, id_to_url: dict[str, str]) -> list[dict]:
    """
    Recebe o texto de uma célula (ex: 'M001, M002, M010') e devolve uma lista
    de rich_text segments com links quando tivermos URL para o ID.

    Estratégia:
    - Usar regex para achar todos os IDs (M\\d+), independente do separador (vírgula, espaço, quebra de linha).
    - Tudo que NÃO é ID vira texto normal.
    - Cada ID vira link se estiver presente em id_to_url, senão vai como texto simples.
    """
    text = original_text or ""
    if not text.strip():
        return []

    rich_segments: list[dict] = []
    pos = 0
    any_id = False

    for match in ID_PATTERN.finditer(text):
        start, end = match.span()
        token = match.group(0)

        # texto entre o fim do último match e o começo deste
        if start > pos:
            prefix = text[pos:start]
            if prefix:
                rich_segments.append(_make_text_segment(prefix))

        url = id_to_url.get(token)
        rich_segments.append(_make_text_segment(token, url=url))
        any_id = True
        pos = end

    # resto da string após o último ID
    if pos < len(text):
        suffix = text[pos:]
        if suffix:
            rich_segments.append(_make_text_segment(suffix))

    if not any_id:
        # não achou nenhum padrão M\\d+ -> não vale a pena mexer
        return []

    return rich_segments


# ==============================================================================
# 6) ATUALIZAR TABELAS DO DB DE PÁGINAS COM LINKS
# ==============================================================================

def _get_id_medidas_col_index(rows: list[dict]) -> int | None:
    """
    Descobre em qual índice de coluna está 'ID Medidas', olhando para a primeira linha de header.
    """
    header_row = None
    for r in rows:
        if r.get("type") == "table_row":
            header_row = r
            break

    if not header_row:
        return None

    cells = header_row.get("table_row", {}).get("cells", [])
    for idx, cell in enumerate(cells):
        header_text = "".join(
            rt.get("plain_text", rt.get("text", {}).get("content", ""))
            for rt in cell
        ).strip()
        if header_text.lower() in {"id medidas", "id medida", "id measures", "id measure"}:
            return idx

    # fallback: se não achar nada, assume última coluna
    if cells:
        return len(cells) - 1

    return None


def update_db3_with_links(db3_id: str, id_to_url: dict[str, str]) -> None:
    """
    Para cada página do DB de Páginas do Relatório, localiza os bancos de dados inline
    "Detalhamento" e, em cada linha, reconstrói completamente o conteúdo da propriedade
    "ID Medidas" como rich_text com links clicáveis para as medidas no DB de Medidas DAX.
    """
    pages = query_all_pages(db3_id)
    print(f"[INFO] Atualizando links em {len(pages)} páginas de '3. Páginas do Relatório' (inline DB Detalhamento)...")

    total_rows = 0
    total_props_com_id = 0
    total_props_atualizadas = 0

    for p in pages:
        page_id = p.get("id")
        title_prop = p.get("properties", {}).get("Página", {})
        title_rt = title_prop.get("title", [])
        page_name = "".join([t.get("plain_text", "") for t in title_rt]) or page_id
        print(f"  > Página: {page_name}")

        # 1) Pega todos os blocos da página (filhos diretos da linha em DB 3)
        page_children = get_block_children(page_id)
        # Procuramos por child_database (inline DB) com título "Detalhamento"
        detalhamento_dbs = []
        for b in page_children:
            if b.get("type") != "child_database":
                continue
            child = b.get("child_database", {}) or {}
            title = child.get("title", "").strip()
            if not title:
                continue
            if title == "Detalhamento":
                detalhamento_dbs.append(b.get("id"))

        if not detalhamento_dbs:
            print("    - Nenhum DB inline 'Detalhamento' encontrado, pulando.")
            continue

        for db_inline_id in detalhamento_dbs:
            # 2) Query em todas as linhas do DB inline "Detalhamento"
            rows = query_all_pages(db_inline_id)
            if not rows:
                continue

            for row in rows:
                rid = row.get("id")
                props = row.get("properties", {})
                id_prop = props.get("ID Medidas")
                if not id_prop:
                    continue

                rich = id_prop.get("rich_text", [])
                original_text = "".join(
                    rt.get("plain_text", rt.get("text", {}).get("content", ""))
                    for rt in rich
                ).strip()

                total_rows += 1

                if not original_text:
                    continue

                total_props_com_id += 1

                new_rich = build_linked_rich_text(original_text, id_to_url)
                if not new_rich:
                    continue

                payload = {
                    "properties": {
                        "ID Medidas": {
                            "rich_text": new_rich
                        }
                    }
                }

                url = f"https://api.notion.com/v1/pages/{rid}"
                r = notion_patch(url, payload)

                if r.status_code != 200:
                    print(
                        f"    [AVISO] Falha ao atualizar propriedade 'ID Medidas' na linha (page_id={rid}): "
                        f"{r.status_code} - {r.text}"
                    )
                else:
                    total_props_atualizadas += 1

    print(
        f"[OK] Atualização concluída. Linhas processadas: {total_rows} | "
        f"propriedades com texto em 'ID Medidas': {total_props_com_id} | "
        f"propriedades efetivamente atualizadas: {total_props_atualizadas}"
    )



# ==============================================================================
# MAIN
# ==============================================================================

def main() -> None:
    print(f"=== Script pós-processamento: Links em ID Medidas ({DB3_NAME}) ===")

    # 1) Localiza DB de Medidas DAX
    db5_id = search_database_by_title(DB5_NAME)
    if not db5_id:
        print(f"[ERRO] Não foi possível localizar o database '{DB5_NAME}'. Encerrando.")
        sys.exit(1)

    # 2) Constrói o mapa ID -> URL
    id_to_url = build_measure_id_to_url_map(db5_id)
    if not id_to_url:
        print(f"[ERRO] Mapa ID->URL vazio. Nada para atualizar em {DB3_NAME}.")
        sys.exit(1)

    # 3) Localiza DB de Páginas do Relatório
    db3_id = search_database_by_title(DB3_NAME)
    if not db3_id:
        print(f"[ERRO] Não foi possível localizar o database '{DB3_NAME}'. Encerrando.")
        sys.exit(1)

    # 4) Atualiza as tabelas do DB de Páginas com links clicáveis
    update_db3_with_links(db3_id, id_to_url)

    print("=== Fim do script. ===")


if __name__ == "__main__":
    main()