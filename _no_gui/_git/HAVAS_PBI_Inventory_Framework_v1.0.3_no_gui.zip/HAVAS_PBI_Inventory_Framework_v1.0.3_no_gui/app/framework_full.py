# -*- coding: utf-8 -*-
import os
import sys
import json
import subprocess
import time
from datetime import datetime
import argparse

# ==============================================================================
# REAL-TIME LOG (evita "limbo" quando stdout é redirecionado para arquivo pela GUI)
# - garante flush linha-a-linha no stdout/stderr
# - propaga PYTHONUNBUFFERED para subprocessos (V2/V4) herdarem o comportamento
# ==============================================================================
try:
    os.environ["PYTHONUNBUFFERED"] = "1"
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True, write_through=True)
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(line_buffering=True, write_through=True)
except Exception:
    pass


# ==============================================================================
# HEADLESS MODE (GUI / sem janelas de console)
# ==============================================================================
HEADLESS = str(os.environ.get("PBI_INVENTORY_HEADLESS", "")).strip().lower() in ("1", "true", "yes")




# ==============================================================================
# UTF-8 SAFE STDOUT/STDERR (Windows / PyInstaller)
# ==============================================================================
def _force_utf8_stdio() -> None:
    """
    Garante que prints/logs não quebrem em Windows (cp1252) quando houver Unicode.
    - Força UTF-8 (quando possível)
    - E usa 'backslashreplace' para nunca dar UnicodeEncodeError
    """
    try:
        import os as _os
        import sys as _sys
        _os.environ.setdefault("PYTHONIOENCODING", "utf-8")
        _os.environ.setdefault("PYTHONUTF8", "1")
        if hasattr(_sys.stdout, "reconfigure"):
            _sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
        if hasattr(_sys.stderr, "reconfigure"):
            _sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")
    except Exception:
        pass

_force_utf8_stdio()

PBI_CONFIG_FILENAME = "pbi_config.json"
NOTION_CONFIG_FILENAME = "notion_config.json"
AI_CONFIG_FILENAME = "ai_config.json"


def is_frozen() -> bool:
    """Retorna True quando o app está empacotado em .exe (PyInstaller)."""
    return getattr(sys, "frozen", False)


def get_base_dir() -> str:
    """
    Retorna a pasta base onde o wrapper está rodando.

    - Em modo .py: pasta do arquivo framework_full.py (ex.: C:\Scripts)
    - Em modo .exe: pasta do executável framework_full.exe
    """
    if is_frozen():
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


# Base: mesma pasta do framework_full (ex.: C:\Scripts)
BASE_DIR = get_base_dir()
SCRIPTS_DIR = BASE_DIR

MINER_BASENAME = "minerador_pbi"
CONSTRUCTOR_BASENAME = "constructor_notion"
NOTION_LINKS_BASENAME = "notion_post_links_ids"
DOTNET_APP_DIR = os.path.join(SCRIPTS_DIR, "pbi_inventory_xmla_net", "PbiInventoryXmla")



def clear_console() -> None:
    """Tenta limpar o console, sem quebrar se não conseguir."""
    try:
        os.system("cls" if os.name == "nt" else "clear")
    except Exception:
        pass


def show_header() -> None:
    print("=" * 80)
    print("HAVAS PBI Inventory Framework - Wrapper Full (V1-V5)".center(80))
    print("=" * 80)
    print()
    print("Este wrapper orquestra as etapas:")
    print("  V2 - Minerador (Python)")
    print("  V3 - .NET XMLA (substitui DAX Studio manual)")
    print("  V4 - Constructor (Notion / Inventário)")
    print("  V5 - Notion Post Links (IDs Medidas -> links)")
    print("-" * 80)
    print()


def ask_project_dir():
    """
    Resolve a pasta do projeto onde está o pbi_config.json.

    Estratégia:
    - Se existir pbi_config.json na pasta atual (cwd), sugere como default.
    - Caso contrário, pede o caminho completo até encontrar um pbi_config.json válido.
    """
    cwd = os.getcwd()
    cfg_here = os.path.join(cwd, PBI_CONFIG_FILENAME)
    default_dir = None

    if os.path.isfile(cfg_here):
        default_dir = cwd
        print(f"📁 Detectei um {PBI_CONFIG_FILENAME} na pasta atual:")
        print(f"    {cwd}")
    else:
        print("📁 Não encontrei pbi_config.json na pasta atual.")
        print("    Caminho atual do terminal:", cwd)

    while True:
        print()
        if default_dir:
            prompt = (
                "Informe a pasta do projeto onde está o pbi_config.json\n"
                "[Enter para usar a pasta detectada acima]\n> "
            )
        else:
            prompt = (
                "Informe a pasta COMPLETA do projeto onde está o pbi_config.json\n> "
            )

        answer = input(prompt).strip().strip('"')

        if not answer:
            if not default_dir:
                print("[ERRO]  Caminho vazio. Informe um diretório válido.")
                continue
            project_dir = default_dir
        else:
            project_dir = answer

        cfg_path = os.path.join(project_dir, PBI_CONFIG_FILENAME)
        if os.path.isfile(cfg_path):
            return project_dir, cfg_path

        print(f"[ERRO]  Não encontrei {PBI_CONFIG_FILENAME} em: {project_dir}")
        print("    Verifique o caminho e tente novamente.")


def load_pbi_config(cfg_path: str) -> dict:
    """Carrega o pbi_config.json, encerrando o wrapper em caso de erro."""
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception as exc:
        print(f"[ERRO]  Erro ao ler {cfg_path}: {exc}")
        sys.exit(1)
    return cfg


def show_config_summary(cfg: dict, project_dir: str) -> None:
    """Mostra um resumo amigável das principais informações do pbi_config.json."""
    print("\nResumo do projeto (pbi_config.json):")
    print("-" * 80)

    project_name = cfg.get("project_name") or cfg.get("project") or "N/D"
    project_url = cfg.get("project_url") or cfg.get("project_link") or ""
    enrich_measures = (
        cfg.get("enrich_measures")
        or cfg.get("measures_enrichment")
        or cfg.get("measures_enrichment_enabled")
    )

    print(f"Projeto.........: {project_name}")
    print(f"Pasta do projeto: {project_dir}")
    if project_url:
        print(f"Link do projeto.: {project_url}")

    if enrich_measures is not None:
        status = "Ativo" if enrich_measures else "Desligado"
        print(
            "Enriquecimento de medidas (Notion).......: "
            f"{status}"
        )

    print("-" * 80)


def ask_yes_no(message: str, default: str = "S") -> bool:
    """Pergunta S/N, com default opcional (S ou N)."""
    default = (default or "").upper()
    while True:
        resp = input(f"{message} (S/N): ").strip().upper()
        if not resp and default in ("S", "N"):
            resp = default
        if resp in ("S", "N"):
            return resp == "S"
        print("Responda apenas com S ou N.")


def run_step(name: str, cmd, cwd: str | None = None):
    """
    Executa uma etapa via subprocess.run, registrando tempo e retorno.

    Retorna (ok: bool, duration_seconds: float).
    """
    print("\n" + "-" * 80)
    print(f"Iniciando etapa: {name}")
    print("-" * 80)

    if isinstance(cmd, (list, tuple)):
        display_cmd = " ".join(str(c) for c in cmd)
    else:
        display_cmd = str(cmd)

    if cwd:
        print(f"Diretório de trabalho (cwd): {cwd}")
    print(f"Comando: {display_cmd}")
    print()

    start = time.time()
    try:
        run_kwargs = {}
        if os.name == "nt" and HEADLESS:
            try:
                creationflags = subprocess.CREATE_NO_WINDOW
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                run_kwargs["creationflags"] = creationflags
                run_kwargs["startupinfo"] = startupinfo
            except Exception:
                # Se não conseguir aplicar flags, segue sem quebrar
                pass

        result = subprocess.run(cmd, cwd=cwd, shell=False, **run_kwargs)
    except KeyboardInterrupt:
        print(f"\n⛔ Etapa '{name}' interrompida pelo usuário.")
        return False, 0.0
    except FileNotFoundError as exc:
        print(f"[ERRO]  Erro ao executar a etapa '{name}': {exc}")
        return False, 0.0

    duration = time.time() - start
    minutes = duration / 60.0

    if result.returncode == 0:
        print(
            f"\n[OK]  Etapa '{name}' concluída com sucesso em "
            f"{minutes:.1f} minuto(s)."
        )
        return True, duration

    print(
        f"\n[AVISO]  Etapa '{name}' finalizada com código {result.returncode} "
        f"em {minutes:.1f} minuto(s)."
    )
    return False, duration


def ensure_path_exists(path: str, description: str, is_dir: bool = False) -> bool:
    """Valida existência de arquivo ou pasta antes de executar o passo."""
    if is_dir:
        if not os.path.isdir(path):
            print(f"[ERRO]  {description} não encontrado(a): {path}")
            return False
    else:
        if not os.path.isfile(path):
            print(f"[ERRO]  {description} não encontrado(a): {path}")
            return False
    return True


def print_summary(steps_results, overall_duration: float) -> None:
    """Mostra um resumo final das etapas e do tempo total da rodada."""
    overall_minutes = overall_duration / 60.0

    print("\n" + "=" * 80)
    print("Resumo da rodada".center(80))
    print("=" * 80)

    for name, ok, dur in steps_results:
        if ok is True:
            status = "OK"
        elif ok is False:
            status = "ERRO/NAO EXECUTADO"
        else:
            status = "PULADO"

        mins = dur / 60.0 if dur else 0.0
        print(f"{name:<30} -> {status:<20} | Tempo: {mins:5.1f} min")

    print("-" * 80)
    print(f"Tempo total da rodada: {overall_minutes:.1f} minuto(s).")

    print("\n SUCESSO TOTAL DO WRAPPER (execução finalizada).")
    print(
        "Se alguma etapa apareceu com ERRO, revise os logs acima "
        "e ajuste antes da próxima rodada."
    )


def _parse_args() -> "argparse.Namespace":
    """
    Interpreta argumentos de linha de comando.

    Pensado principalmente para modo DEV e cenários avançados.
    A GUI normalmente apenas passará --project-dir.
    """
    parser = argparse.ArgumentParser(
        description=(
            "HAVAS PBI Inventory Framework - Wrapper Full (engine sem interação no terminal)."
        )
    )
    parser.add_argument(
        "--project-dir",
        "-p",
        help=(
            "Caminho da pasta do projeto Power BI onde está o pbi_config.json. "
            "Se não for informado, o wrapper tentará usar o diretório atual "
            "ou a variável de ambiente PBI_INVENTORY_PROJECT_DIR."
        ),
    )
    for step, help_suffix in [
        ("v2", "etapa V2 - Minerador (Python)"),
        ("v3", "etapa V3 - .NET XMLA"),
        ("v4", "etapa V4 - Constructor (Notion / Inventário)"),
        ("v5", "etapa V5 - Notion Post Links"),
    ]:
        parser.add_argument(
            f"--run-{step}",
            choices=["auto", "yes", "no"],
            default="auto",
            help=(
                "Força execução (yes), pular (no) ou manter comportamento automático (auto) da "
                + help_suffix
                + "."
            ),
        )
    return parser.parse_args()


def _resolve_project_dir(arg_project_dir: str | None) -> tuple[str, str]:
    """
    Define a pasta do projeto sem perguntar nada no console.

    Ordem de busca:
      1) --project-dir / -p
      2) variável de ambiente PBI_INVENTORY_PROJECT_DIR
      3) diretório atual, se contiver pbi_config.json
    """
    candidates: list[tuple[str, str]] = []

    if arg_project_dir:
        candidates.append(("parâmetro --project-dir", arg_project_dir))

    env_dir = os.getenv("PBI_INVENTORY_PROJECT_DIR")
    if env_dir:
        candidates.append(("variável de ambiente PBI_INVENTORY_PROJECT_DIR", env_dir))

    cwd = os.getcwd()
    candidates.append(("diretório atual", cwd))

    for origin, folder in candidates:
        folder = folder.strip().strip('"')
        cfg_path = os.path.join(folder, PBI_CONFIG_FILENAME)
        if os.path.isfile(cfg_path):
            print(f"📁 Usando pasta do projeto informada via {origin}:")
            print(f"    {folder}")
            return folder, cfg_path

    print("[ERRO]  Não foi possível localizar um pbi_config.json automaticamente.")
    print()
    print("Informe a pasta do projeto de uma das seguintes formas:")
    print("  - Chamando o wrapper com: framework_full.exe --project-dir C:\\caminho\\do\\projeto")
    print("  - Definindo a variável de ambiente PBI_INVENTORY_PROJECT_DIR antes de executar; ou")
    print("  - Abrindo o terminal diretamente na pasta do projeto (onde está o pbi_config.json).")
    sys.exit(1)


def _resolve_step_flag(cfg: dict, cfg_key: str, cli_value: str, default: bool) -> bool:
    """
    Define se uma etapa deve rodar ou não.

    Precedência:
      1) Parâmetro de linha de comando: yes/no/auto.
      2) Chave booleana no pbi_config.json (cfg_key).
      3) Valor default informado.
    """
    if cli_value == "yes":
        return True
    if cli_value == "no":
        return False

    cfg_val = cfg.get(cfg_key)
    if isinstance(cfg_val, bool):
        return cfg_val

    return default


def main() -> int:
    clear_console()
    show_header()

    overall_start = time.time()

    # 1) Argumentos de linha de comando / resolução da pasta do projeto
    args = _parse_args()
    project_dir, cfg_path = _resolve_project_dir(args.project_dir)
    cfg = load_pbi_config(cfg_path)
    show_config_summary(cfg, project_dir)

    # Checagens de configuração global (Notion / IA)
    notion_config_path = os.path.join(SCRIPTS_DIR, NOTION_CONFIG_FILENAME)
    notion_config_exists = os.path.isfile(notion_config_path)

    if not notion_config_exists:
        print("\n[AVISO]  Arquivo de configuração do Notion não encontrado.")
        print(f"   Esperado em: {notion_config_path}")
        print("   As etapas V4 (Constructor) e V5 (Notion Post Links) podem ser puladas")
        print("   automaticamente se você não configurar este arquivo.\n")

    ai_config_path = os.path.join(SCRIPTS_DIR, AI_CONFIG_FILENAME)
    ai_config_exists = os.path.isfile(ai_config_path)
    use_ai = bool(
        cfg.get("use_ai_enrichment")
        if "use_ai_enrichment" in cfg
        else cfg.get("measures_enrichment_enabled", False)
    )

    if use_ai and not ai_config_exists:
        print("\n[AVISO]  IA marcada como ativa (use_ai_enrichment = true no pbi_config.json),")
        print(f"   mas o arquivo de configuração da IA não foi encontrado em: {ai_config_path}")
        print("   O enriquecimento automático de descrições por IA será ignorado pelo Constructor (V4).")
        print("   Se desejar usar IA, configure o ai_config.json e rode novamente em outra rodada.\n")

    # 2) Decisão de execução por etapa (sem perguntas no terminal)
    run_v2 = _resolve_step_flag(cfg, "run_v2_miner", args.run_v2, True)
    run_v3 = _resolve_step_flag(cfg, "run_v3_dotnet", args.run_v3, True)
    run_v4 = _resolve_step_flag(cfg, "run_v4_constructor", args.run_v4, True)
    run_v5 = _resolve_step_flag(cfg, "run_v5_links", args.run_v5, True)

    # Ajuste automático: se Notion não estiver configurado, V4/V5 são desativadas.
    if (run_v4 or run_v5) and not notion_config_exists:
        print(
            "\n[AVISO]  Notion não está configurado (notion_config.json ausente). "
            "As etapas V4 (Constructor) e V5 (Notion Post Links) serão puladas "
            "automaticamente nesta rodada."
        )
        run_v4 = False
        run_v5 = False

    steps_results: list[tuple[str, bool | None, float]] = []

    # 3) V2 - Minerador (Python ou EXE)
    if run_v2:
        if is_frozen():
            miner_path = os.path.join(SCRIPTS_DIR, f"{MINER_BASENAME}.exe")
            desc = "Executável minerador_pbi.exe"
            cmd = [miner_path]
        else:
            miner_path = os.path.join(SCRIPTS_DIR, f"{MINER_BASENAME}.py")
            desc = "Script minerador_pbi.py"
            cmd = [sys.executable, miner_path]

        if ensure_path_exists(miner_path, desc):
            ok, dur = run_step("V2 - Minerador (Python)", cmd, cwd=project_dir)
            steps_results.append(("V2 - Minerador", ok, dur))
        else:
            steps_results.append(("V2 - Minerador", False, 0.0))
    else:
        print("[PULADO]  V2 - Minerador (Python) NÃO executado (configuração).")
        steps_results.append(("V2 - Minerador", None, 0.0))

    # 4) V3 - .NET XMLA
    step_name = "V3 - .NET XMLA"
    if run_v3:
        # Lê a connection string vinda da GUI (pbi_config.json)
        xmla_conn = (
            cfg.get("xmla_connection_string")
            or cfg.get("powerbi_connection_string")
            or cfg.get("connection_string")
            or ""
        )
        project_name = (cfg.get("project_name") or cfg.get("project") or "").strip()
        if not project_name:
            project_name = os.path.basename(os.path.normpath(project_dir))

        if not xmla_conn.strip():
            print("[ERRO]  V3 ativada, mas não encontramos a connection string XMLA no pbi_config.json.")
            print("        Preencha o campo na GUI e rode novamente.")
            ok, dur = False, 0.0
        else:
            # Monta argumentos para execução 100% sem prompt no .NET
            v3_args = [
                "--mode", "full",
                "--connection", xmla_conn,
                "--project-name", project_name,
                "--output-folder", project_dir,
                "--headless",
            ]

            if is_frozen():
                # Modo empacotado (.exe): chamamos o executável self-contained
                dotnet_exe_path = os.path.join(SCRIPTS_DIR, "PbiInventoryXmla.exe")
                desc = "Executável PbiInventoryXmla.exe"
                if ensure_path_exists(dotnet_exe_path, desc):
                    ok, dur = run_step(step_name, [dotnet_exe_path] + v3_args, cwd=project_dir)
                else:
                    ok, dur = False, 0.0
            else:
                # Modo DEV (.py): usamos "dotnet run" apontando para a pasta do projeto .NET
                # (pbi_inventory_xmla_net\PbiInventoryXmla)
                if ensure_path_exists(
                    DOTNET_APP_DIR,
                    "Pasta do aplicativo .NET (pbi_inventory_xmla_net)",
                    is_dir=True,
                ):
                    ok, dur = run_step(step_name, ["dotnet", "run", "--"] + v3_args, cwd=DOTNET_APP_DIR)
                else:
                    ok, dur = False, 0.0

        steps_results.append((step_name, ok, dur))
    else:
        print("[PULADO]  V3 - .NET XMLA NÃO executado (configuração).")
        steps_results.append((step_name, None, 0.0))

    # 5) V4 - Constructor
    if run_v4:
        if is_frozen():
            constructor_path = os.path.join(SCRIPTS_DIR, f"{CONSTRUCTOR_BASENAME}.exe")
            desc = "Executável constructor_notion.exe"
            cmd = [constructor_path]
        else:
            constructor_path = os.path.join(SCRIPTS_DIR, f"{CONSTRUCTOR_BASENAME}.py")
            desc = "Script constructor_notion.py"
            cmd = [sys.executable, constructor_path]

        if ensure_path_exists(constructor_path, desc):
            ok, dur = run_step("V4 - Constructor", cmd, cwd=project_dir)
            steps_results.append(("V4 - Constructor", ok, dur))
        else:
            steps_results.append(("V4 - Constructor", False, 0.0))
    else:
        print("[PULADO]  V4 - Constructor NÃO executado (configuração).")
        steps_results.append(("V4 - Constructor", None, 0.0))

    # 6) V5 - Notion Post Links
    if run_v5:
        if is_frozen():
            notion_links_path = os.path.join(
                SCRIPTS_DIR, f"{NOTION_LINKS_BASENAME}.exe"
            )
            desc = "Executável notion_post_links_ids.exe"
            cmd = [notion_links_path]
        else:
            notion_links_path = os.path.join(
                SCRIPTS_DIR, f"{NOTION_LINKS_BASENAME}.py"
            )
            desc = "Script notion_post_links_ids.py"
            cmd = [sys.executable, notion_links_path]

        if ensure_path_exists(notion_links_path, desc):
            ok, dur = run_step("V5 - Notion Post Links", cmd)
            steps_results.append(("V5 - Notion Post Links", ok, dur))
        else:
            steps_results.append(("V5 - Notion Post Links", False, 0.0))
    else:
        print("[PULADO]  V5 - Notion Post Links NÃO executado (configuração).")
        steps_results.append(("V5 - Notion Post Links", None, 0.0))

    overall_duration = time.time() - overall_start
    print_summary(steps_results, overall_duration)


if __name__ == "__main__":
    main()