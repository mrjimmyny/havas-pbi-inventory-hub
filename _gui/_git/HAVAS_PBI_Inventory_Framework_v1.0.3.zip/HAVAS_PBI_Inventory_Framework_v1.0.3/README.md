# HAVAS PBI Inventory Framework — Release HAVAS_PBI_Inventory_Framework_v1.0.3

## O que é isso
Pacote **portátil** (ZIP) para rodar o inventário via **GUI** no Windows, sem instalador.

## Como rodar (2 minutos)
1) Extraia este ZIP em uma pasta local (ex.: `C:\Scripts\HAVAS_PBI_Inventory_Framework_v1.0.3`).
2) Abra a pasta `app\` e (se aplicável) preencha:
   - `app\notion_config.json` (Notion API Key + IDs/DBs necessários)
   - `app\ai_config.json` (API Key da IA + modelo)
   > Se você NÃO vai usar IA agora, deixe o campo `api_key` vazio.
3) Para rodar em um projeto PBIP (.pbip):
   - Copie `app\pbi_config.json` para a pasta raiz do seu projeto `.pbip` (no mesmo nível das pastas do projeto)
   - Preencha os campos do arquivo conforme seu projeto
4) Abra a pasta `app\` e dê duplo clique em **inventory_gui.exe**.
5) Na GUI, selecione/crie a pasta do seu projeto e preencha a conexão XMLA (ou cole a connection string).
6) Clique em **Run Inventory** e aguarde o resumo final.

> Por política corporativa (DLP), este release **não usa .BAT**.

## Arquivos importantes
- `app\inventory_gui.exe` → executável principal (GUI)
- `app\framework_full.exe` → orquestrador (usado internamente pela GUI)
- `app\notion_config.json` → config do Notion (template)
- `app\ai_config.json` → config da IA (template)
- `app\pbi_config.json` → template do projeto (copiar para a pasta do seu `.pbip`)
- `docs\checksums.md` → hashes SHA-256 dos executáveis

## Regras rápidas
- Mantenha **todos os .exe e os 3 arquivos de config na pasta `app\`** (a GUI chama os módulos por caminho relativo).
- Se mover a pasta inteira, ok. Se mover só um arquivo, pode quebrar.

## Suporte (sem admin)
Se der erro:
1) abra `app\inventory_gui.exe` normalmente e copie o trecho do log da própria GUI
2) se precisar de detalhe extra, rode pelo CMD (na pasta `app\`): `inventory_gui.exe`
