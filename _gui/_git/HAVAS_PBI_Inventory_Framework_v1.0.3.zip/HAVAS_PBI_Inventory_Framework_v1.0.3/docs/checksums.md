# Checksums (SHA-256)
| File | Size (bytes) | SHA-256 |
|---|---:|---|
| PbiInventoryXmla.exe | 75099064 | 5a484f338632bab77a6f8b75a16f0ee037e777856b2249dee2fce38d8befa2b0 |
| constructor_notion.exe | 17525402 | a52c1310e03d58cd8b92fcc7d0577b229bfdcaef28e36a3c82bac0a0bae788f2 |
| framework_full.exe | 8393476 | 9dbdea5e8984d724489a570c3665ce49ce4487ce2504d569cba0d0486d289d54 |
| inventory_gui.exe | 11694473 | 9b45bb50e83a733bed305177ca85a1afc338a5c37a394137491df3adbd22ef49 |
| minerador_pbi.exe | 8397231 | f0404d6d6827d202d039c602a52ce2efe434618cd7ed5100b2e68c054c0e3a56 |
| notion_post_links_ids.exe | 12034041 | c94a0ef8e6e1180f47f6812c5a824a5a7c93d30b90897112b1f9fc6414f00729 |
