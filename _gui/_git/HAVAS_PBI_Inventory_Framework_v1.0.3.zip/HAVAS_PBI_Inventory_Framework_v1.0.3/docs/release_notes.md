# Release Notes

## v1.0.3
- **Ajuste de empacotamento (fix de path):** `ai_config.json`, `notion_config.json` e `pbi_config.json` agora ficam **na pasta `app\`**, junto dos executáveis (evita erro de "arquivo não localizado").
- Nenhuma mudança funcional nos módulos (V2–V5).

## v1.0.2
- Ajuste de empacotamento para ambiente corporativo: release **sem .BAT**.
- Nenhuma mudança funcional nos módulos (V2–V5).

## v1.0.0
- Primeiro release público (ZIP portátil) com GUI e módulos V2–V5.
